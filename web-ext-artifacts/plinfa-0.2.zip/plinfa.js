function fetchTitles(){
    var all_videos = document.getElementsByTagName("ytd-item-section-renderer");
    var all_titles = document.getElementsByClassName("title-and-badge");
    console.log("1"):
    for (var i = 0; i < all_videos.length; i++){
            video = all_videos.item(i);
            title = all_titles.item(i).children.namedItem("video-title").text;
            console.log(title);
    }
}

function initStorage() {
    browser.storage.local.get().then((blackList) => {
        console.log(blackList)
    }).catch(()=> {
        console.log("Error retrieving the blacklist");
    });
}


initStorage();
// fetchTitles();

// browser.storage.local.remove("test").then(()=> console.log("success"));
