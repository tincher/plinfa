# This is Plinfa

Plinfa lets you modify your youtube subscriptions, by applying a blacklist to your subscriptions.
Modifying your blacklist is made easy by either adding them via the usual popup or the search bar icon, in which it already copies the title (or maybe the tags, i dont know yet dude) and lets you edit this.

I still have to think about the removal of items from the blacklist, but since i dont know how to store it yet (next step) so i don't know how to delete it yet DUH.

But also maybe this will never be finished, so you might be wasting your time by reading this, but if you read everything, good job on procrastinating on whatever you really wanted to do instead.
